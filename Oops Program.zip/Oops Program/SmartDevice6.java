interface SmartDevice{
void turnOn();
void turnOff();
}
class SmartLight implements SmartDevice{
public void turnOn()
{
System.out.println("Smart Light is ON");
}
public void turnOff()
{
System.out.println("Smart Light is OFF");
}
}
class SmartFan implements SmartDevice{
public void turnOn()
{
System.out.println("Smart Fan is ON");
}
public void turnOff()
{
System.out.println("Smart Fan is OFF");
}
}
public class SmartDevice6{
public static void main(String[] args){
SmartDevice li=new SmartLight();
SmartDevice fa=new SmartFan();
li.turnOn();
li.turnOff();
fa.turnOn();
fa.turnOff();
}
}


