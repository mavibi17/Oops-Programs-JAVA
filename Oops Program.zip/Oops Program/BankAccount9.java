class BankAccount{
int accountNumber;
double balance;
BankAccount(){
accountNumber=2000;
balance=300;
}
BankAccount(int accNo,double initialBalance){
accountNumber=accNo;
balance=initialBalance;
}
void deposit(double amount){
balance=balance+amount;
System.out.println("Deposited:"+amount);
}
void withdraw(double amount){
if(amount<=balance){
balance=balance-amount;
System.out.println("Withdraw:"+amount);
}
else
{
System.out.println("Null Balance");
}
}
void displayAccount(){
System.out.println("Account Number: " + accountNumber);
System.out.println("Balance: " + balance);
}
}
public class BankAccount9{
public static void main(String[] args){
BankAccount acc = new BankAccount();
acc.displayAccount();
acc.deposit(500);
acc.withdraw(200);
acc.displayAccount();
System.out.println();
BankAccount acco=new BankAccount(3000,10000);
acco.displayAccount();
acco.withdraw(400);
acco.displayAccount();
}
}


