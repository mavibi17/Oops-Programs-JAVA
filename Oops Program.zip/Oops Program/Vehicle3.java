class Vehicle{
String brand;
int speed;
void start()
{
System.out.println("Vehicle Started");
}
void stop()
{
System.out.println("Vehicle Stopped");
}
}
class Car extends Vehicle{
void openTrunk()
{
System.out.println("Open");
}
}
class Bike extends Vehicle{
void kickstart()
{
System.out.println("Kick");
}
}
public class Vehicle3{
public static void main(String[] args){
Car c=new Car();
c.brand="Honda";
c.speed=70;
c.start();
c.openTrunk();
c.stop();
System.out.println();
Bike b=new Bike();
b.brand="BMW";
b.speed=60;
b.start();
b.kickstart();
b.stop();
System.out.println();
}
}                                                                                                                                                         




