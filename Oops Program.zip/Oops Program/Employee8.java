class Employee{
static String companyName = "TCS";
static int employeeCount = 0;
int employeeId;
String employeeName;
Employee(String name){
employeeName = name;
employeeCount++;
employeeId=employeeCount;
}
static int getEmployeeCount(){
return employeeCount;
}
void displayEmployee() {
System.out.println("Company Name : " + companyName);
System.out.println("Employee ID  : " + employeeId);
System.out.println("Employee Name: " + employeeName);
}
}
class Employee8{
public static void main(String[] args){
Employee e1=new Employee("Fire");
Employee e2=new Employee("Ash");
Employee e3=new Employee("Water");
e1.displayEmployee();
e2.displayEmployee();
e3.displayEmployee();
System.out.println("Total numbers of Employee:"+Employee.getEmployeeCount());
}
}