class Stu{
String Studentname;
int rollnumber;
int marks;
void setDetails(String Studentname,int rollnumber,int marks) {
this.Studentname=Studentname;
this.rollnumber=rollnumber;
this.marks=marks;
}
void displayDetails() {
System.out.println("Name:" +Studentname); 
System.out.println("Rollno:" +rollnumber);
System.out.println("Marks:" +marks);
}
boolean ispassed() {
if(marks>=40) {
return true;
}
else {
return false;
}
} 
}
public  class Student1 {
public static void main(String[] args) {
Stu s1=new Stu();
s1.setDetails("AA",123,89);
Stu s2=new Stu();
s2.setDetails("BB",234,70);
Stu s3=new Stu();
s3.setDetails("CC",231,28);
s1.displayDetails();
s2.displayDetails();
s3.displayDetails();
}
}

             