class Student{
public String name;
private int marks;
protected String grade;
int rollNumber;
public void setMarks(int marks){
if(marks>=0 &&marks <=100)
{
this.marks=marks;
calculateGrade();
}
else
{
System.out.println("Not available marks! Enter 0-100");
}
}
private void calculateGrade(){
if(marks>=90)
grade="A";
else if(marks>=80)
grade="B";
else if(marks>=70)
grade="C";
else if(marks>=60)
grade="D";
else
grade="Fail";
}
public String getGrade(){
return grade;
}
protected void displayBasicInfo()
{
System.out.println("Name:"+name);
System.out.println("Roll Number:"+rollNumber);
}
}
class Marks7
{
public static void main(String[] args)
{
Student s=new Student();
s.name="Anu";
s.rollNumber=304;
s.setMarks(89);
System.out.println("Grade:"+s.getGrade());
s.displayBasicInfo();
}
}
