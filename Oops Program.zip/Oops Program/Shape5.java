abstract class Shape{
abstract double calculateArea();
void displayShape()
{
System.out.println("This is Shape");
}
}
class Circle extends Shape{
double radius;
Circle(double radius)
{
this.radius=radius;
}
double calculateArea()
{
return 3.14 * radius * radius;
}
}
class Rectangle extends Shape{
double length,breadth;
Rectangle(double length,int breadth)
{
this.length=length;
this.breadth=breadth;
}
double calculateArea()
{
return length*breadth;
}
}
public class Shape5{
public static void main(String[] args){
Shape c=new Circle(4);
c.displayShape();
System.out.println("Circle Area is:"+c.calculateArea());
Shape r=new Rectangle(3,6);
r.displayShape();
System.out.println("Rectangle Area is:"+r.calculateArea());
}
}
