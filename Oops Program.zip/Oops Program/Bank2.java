class Bank{
private int accountNumber;
private double balance;
Bank(int accountNumber,double initBalance){
this.accountNumber=accountNumber;
if(initBalance>0){
balance=initBalance;
}
else{
balance=0;
}
}
public void deposit(double amount){
if(amount>0){
balance=balance+amount;
System.out.println("Deposited:"+amount);
}
else
{
System.out.println("Invalid");
}
}
public void withdraw(double amount){
if (amount > 0 && amount <= balance){
balance = balance - amount;
System.out.println("Withdrawn: " + amount);
}
else 
{
System.out.println("Invalid withdraw amount");
}
}
public double getBalance()
{
return balance;
}
}
public class Bank2{
public static void main(String[] args){
Bank account=new Bank(120,50000);
account.deposit(2500);
account.withdraw(3000);
System.out.println("Balance:"+account.getBalance());
}
}


