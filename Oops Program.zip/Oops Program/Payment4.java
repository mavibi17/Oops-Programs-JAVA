class Payment{
void pay(double amount)
{
System.out.println("Payment"+amount);
}
}
class CreditCardPayment extends Payment{
void pay(double amount)
{
System.out.println("Paid"+amount+"using the Credit card");
}
}
class UPIPayment extends Payment{
void pay(double amount)
{
System.out.println("Paid"+amount+"using the UPI");
}
}
public class Payment4{
public static void main(String[] args){
Payment pa;
pa=new CreditCardPayment();
pa.pay(1230);
pa=new UPIPayment();
pa.pay(5000);
}
}

